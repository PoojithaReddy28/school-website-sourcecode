import React from 'react';

export function Name({name}) {
    return (
        <h1 style={{color: 'red'}}>{name}</h1>
    );
}